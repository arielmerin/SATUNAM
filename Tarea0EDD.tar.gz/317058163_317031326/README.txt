317058163 Aquino Chapa Armando Abraham
317031326 Merino Peña Kevin Ariel

En la carpeta principal viene un .jar que ejecuta el mismo codigo que viene en la carpta "code" para correr el programa desde la terminal, posicionarse en la carpeta y escribir

java -jar DGPUNAM.jar


